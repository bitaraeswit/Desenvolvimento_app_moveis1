import com.photos.Photo

val photosG = mutableListOf<Photo>()
